# p2p-file-sharing
Assignment 1 of Computer Network course.

Write your name here to complete Task 1.1:
- nkhoa
- minhtriet
- nvhuy
